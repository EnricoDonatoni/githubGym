exports.check = function(question, answer){
	if(question == answer){
		return 1;
	}
	else{
		return 0;
	}
}

exports.idnonvalido = function(res, domande){

		var rand = Math.round((Math.random()*(domande.length-1)));
		//console.log(rand)
		if(domande.length==0){
			res.setHeader('Content-Type', 'application/json');
		res.status(400).json({
			status: "Senza domande"
		});
		}
		else{
		res.setHeader('Content-Type', 'application/json');
		res.status(200).json({
			question: domande[rand].question,
			idq: rand
		});
	}
}