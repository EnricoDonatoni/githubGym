var sendandreceive = function(){

	var form = document.getElementById("myform2");

    var data = {};
    
    //con for prendo tutti i campi che hanno un nome, ovvero quelli che voglio inviare al server
    for (var i = 0; i < form.length; i++) {
        var input = form[i];
        if (input.name) {
            data[input.name] = input.value;
        }
    }

    console.log(data);


    const ul = document.getElementById('authors'); // Get the list where we will place our authors
    const url = form.action //+ "?id=" + data.id; // Get 10 random users        
    fetch(url)
        .then((resp) => resp.json()) // Transform the data into json
        .then(function(data) {
            console.log(data);
        })
        .catch( error => console.error(error) );// If there is any error you will catch them here



}

var rispostacorretta = function(){

	var form = document.getElementById("myform3");

    var data = {};
    
    //con for prendo tutti i campi che hanno un nome, ovvero quelli che voglio inviare al server
    for (var i = 0; i < form.length; i++) {
        var input = form[i];
        if (input.name) {
            data[input.name] = input.value;
        }
    }

    console.log(data)

    var myHeaders = new Headers();
    myHeaders.append("Access-Control-Allow-Origin", "*");


     fetch(form.action,{
	    method: 'post',
	    body: JSON.stringify(data),
	    headers: myHeaders,
		mode: 'no-cors',
		cache: 'default' 
	  })
        .then((resp) => resp.json()) // Transform the data into json
        .then(function(data) {
            console.log(data);
        })
        .catch( error => console.error(error) );// If there is any error you will catch them here

}