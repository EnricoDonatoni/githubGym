var somma = function(){
	var lato1 = document.getElementById("a").value
	var lato2 = document.getElementById("b").value

	a= parseInt(lato1)
	b= parseInt(lato2)
	var lati = []
	lati.push(a)
	lati.push(b)
	document.getElementById("ris").innerHTML = "" + sum(lati);
}

function sum(lati){
	if(typeof(lati)!== "undefined"){
		if(lati.length==2){
			if((lati[0]>0)&&(lati[1]>0)){
				return lati[0]+lati[1]
			}
		}
	}
	return -1
}