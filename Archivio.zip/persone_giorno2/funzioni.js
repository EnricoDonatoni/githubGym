exports.maggiorenne = function(x){
	if(x >= 18){
		return 1;
	}
	else{
		return 0;
	}
}