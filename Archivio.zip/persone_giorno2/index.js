//express
var express = require('express');
var bodyParser = require('body-parser');
//inspect variables
var util = require('util');
var modulo = require("./funzioni.js");

//instantiate express
var app = express();

var persone = [];

app.get("/persone", function(req, res){

	var id = req.query.id;
	if(typeof(id) === "undefined"){
		res.setHeader('Content-Type', 'application/json');
		res.status(200).json({
			numeropersone: persone.length,
			items: persone
		});
	}
	else{

		var n = parseInt(id);
		if((n < 0) || (n > persone.length)){
			res.setHeader('Content-Type', 'application/json');
			res.status(400).json({
				errore: "Out of range"
			});
		}
		else{
			res.setHeader('Content-Type', 'application/json');
			res.status(200).json({
				persona: persone[n],
				mag: modulo.maggiorenne(persone[n].eta)
			});
		}

	}
    
})

app.post("/persone", function(req, res){
   
    var nome = req.query.nome;
    var eta = req.query.eta;

    var error = "";
    var persona;

    if(typeof(nome) === "undefined"){
    	error = "Inserire un nome valido";
    }
    else{
	    if(typeof(eta) === "undefined"){
	    	error = "Inserire un'eta valida";
	    }	
	    else{
	    	var anni = parseInt(eta);
	    	if(anni <= 0){
	    		error = "Inserire un'età positiva"
	    	}
	    	else{
	    		persona = {
	    			nome: nome,
	    			eta: anni
	    		}
	    		persone.push(persona);
	    	}
	    }
    }

    if(error != ""){
    	res.setHeader('Content-Type', 'application/json');
    	res.status(400).json({
    		errore: error
    	});
    }
    else{	    	
		res.status(200).json({
			status: "Ok! Persona aggiunta",
			pos: persone.length - 1
		});
    }

});

//listen in a specific port
app.listen((process.env.PORT || 65000));

//check status
console.log('Server running at http://localhost:65000/');