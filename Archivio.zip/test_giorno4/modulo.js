exports.somma = function(a, b){
	return a+b;
}