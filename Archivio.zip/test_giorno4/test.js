var m = require("./modulo.js");

test('adds 1 + 2 to equal 3', () => {
  expect(m.somma(1, 2)).toBe(3);
});test('adds 1 + 2 to equal 3', () => {
  expect(m.somma(1, 2)).toBe(4);
});test('adds 1 + 2 to equal 3', () => {
  expect(m.somma(1, 2)).toBe(3);
});test('adds 1 + 2 to equal 3', () => {
  expect(m.somma(1, 2)).toBe(3);
});